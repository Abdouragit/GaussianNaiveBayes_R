# GaussianNaiveBayes in R
We created this project in the context of our master's degree in statistics and computer science specialized in data science.
